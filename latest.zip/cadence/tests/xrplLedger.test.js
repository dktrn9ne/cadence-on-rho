import { beforeEach, describe, expect, it, vi } from "vitest";

// Contract tests for the reconciliation read (PR 04): a lookup by transaction
// hash normalizes to validated_success | validated_failure | still_unknown,
// decided only by the ledger's meta.TransactionResult. Every transport or
// server failure — and every unreadable response — resolves still_unknown:
// an unknown outcome must never be guessed as success or failure, because
// only validated_success may advance a plan.

import {
  OUTCOMES,
  classifyTransactionResult,
  isValidTxHash,
  lookupTransaction,
  lookupWithClient,
} from "../src/services/xrplLedger.js";
import { RLUSD_CURRENCY, RLUSD_ISSUER, SOURCE_TAG } from "../src/domain/xrpl-constants.js";

const XRPL_WS_URL = "wss://s1.ripple.com";
const HASH = "9A4C000000000000000000000000000000000000000000000000000000000F01";

// ---- pure classification -------------------------------------------------

describe("classifyTransactionResult", () => {
  it("classifies tesSUCCESS as validated_success", () => {
    expect(
      classifyTransactionResult({ validated: true, meta: { TransactionResult: "tesSUCCESS" } })
    ).toBe(OUTCOMES.SUCCESS);
  });

  it("classifies every other ledger result code as validated_failure", () => {
    // tec/tef/tem/tej are all "the ledger answered, and not with success".
    for (const code of ["tecUNFUNDED_PAYMENT", "tecNO_LINE", "tefBAD_AUTH", "temBAD_CURRENCY"]) {
      expect(classifyTransactionResult({ validated: true, meta: { TransactionResult: code } })).toBe(
        OUTCOMES.FAILURE
      );
    }
  });

  it("classifies an unreadable or missing verdict as still_unknown", () => {
    expect(classifyTransactionResult(undefined)).toBe(OUTCOMES.UNKNOWN);
    expect(classifyTransactionResult({})).toBe(OUTCOMES.UNKNOWN);
    expect(classifyTransactionResult({ meta: {} })).toBe(OUTCOMES.UNKNOWN);
    expect(classifyTransactionResult({ meta: { TransactionResult: "" } })).toBe(OUTCOMES.UNKNOWN);
  });

  // Ported from main's superseded ledgerReconciler.test.js (PR #15, unwired):
  // a transaction the ledger has not validated yet carries provisional meta
  // that can still flip before the ledger closes — it is never a verdict.
  it("keeps a transaction that is not yet validated unresolved, whatever its meta says", () => {
    for (const meta of [
      { TransactionResult: "tesSUCCESS" },
      { TransactionResult: "tecUNFUNDED_PAYMENT" },
    ]) {
      expect(classifyTransactionResult({ meta, validated: false })).toBe(OUTCOMES.UNKNOWN);
    }
    expect(
      classifyTransactionResult({ meta: { TransactionResult: "tesSUCCESS" }, validated: true })
    ).toBe(OUTCOMES.SUCCESS);
  });
});

// Ported from main's superseded normalizeOutcome.test.js (PR #15, unwired):
// a hash that cannot be looked up is no hash — garbage hashes resolve
// still_unknown without a network round-trip instead of a doomed request.
describe("isValidTxHash", () => {
  it("accepts 64 hex characters in either case", () => {
    expect(isValidTxHash(HASH)).toBe(true);
    expect(isValidTxHash(HASH.toLowerCase())).toBe(true);
  });

  it("rejects anything else", () => {
    expect(isValidTxHash("")).toBe(false);
    expect(isValidTxHash(HASH.slice(1))).toBe(false); // 63 chars
    expect(isValidTxHash(`${HASH}F0`)).toBe(false); // 66 chars
    expect(isValidTxHash(`x${HASH.slice(1)}`)).toBe(false); // non-hex character
    expect(isValidTxHash(null)).toBe(false);
    expect(isValidTxHash(42)).toBe(false);
  });
});

// ---- lookupWithClient: the mocked-client seam -----------------------------

const makeClient = (impl) => ({ request: vi.fn(impl) });

describe("lookupWithClient", () => {
  it("requests the transaction by hash and reports validated_success", async () => {
    const client = makeClient(async () => ({
      result: { validated: true, hash: HASH, meta: { TransactionResult: "tesSUCCESS" } },
    }));
    await expect(lookupWithClient(client, HASH)).resolves.toEqual({
      outcome: OUTCOMES.SUCCESS,
    });
    expect(client.request).toHaveBeenCalledWith({ command: "tx", transaction: HASH });
  });

  it("reports validated_failure from ledger failure meta", async () => {
    const client = makeClient(async () => ({
      result: { validated: true, hash: HASH, meta: { TransactionResult: "tecUNFUNDED_PAYMENT" } },
    }));
    await expect(lookupWithClient(client, HASH)).resolves.toEqual({
      outcome: OUTCOMES.FAILURE,
    });
  });

  it("resolves still_unknown when the server cannot find the transaction", async () => {
    // Shape of the error the xrpl client raises for an error response.
    const txnNotFound = Object.assign(new Error("Transaction not found."), {
      name: "ResponseError",
      data: { error: "txnNotFound" },
    });
    const client = makeClient(async () => {
      throw txnNotFound;
    });
    await expect(lookupWithClient(client, HASH)).resolves.toEqual({
      outcome: OUTCOMES.UNKNOWN,
    });
  });

  it("resolves still_unknown on any transport failure", async () => {
    for (const error of [
      new Error("connection timed out"),
      new Error("socket hang up"),
      Object.assign(new Error("not connected"), { name: "NotConnectedError" }),
    ]) {
      const client = makeClient(async () => {
        throw error;
      });
      await expect(lookupWithClient(client, HASH)).resolves.toEqual({
        outcome: OUTCOMES.UNKNOWN,
      });
    }
  });

  it("resolves still_unknown when the response carries no readable meta", async () => {
    const client = makeClient(async () => ({ result: { hash: HASH } }));
    await expect(lookupWithClient(client, HASH)).resolves.toEqual({
      outcome: OUTCOMES.UNKNOWN,
    });
  });

  it("never touches the network for a missing or empty hash", async () => {
    const client = makeClient(async () => {
      throw new Error("lookup must not be attempted");
    });
    await expect(lookupWithClient(client, "")).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
    await expect(lookupWithClient(client, null)).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
    expect(client.request).not.toHaveBeenCalled();
  });

  it("never touches the network for a malformed hash (ported from normalizeOutcome)", async () => {
    const client = makeClient(async () => {
      throw new Error("lookup must not be attempted");
    });
    await expect(lookupWithClient(client, HASH.slice(1))).resolves.toEqual({
      outcome: OUTCOMES.UNKNOWN,
    });
    await expect(lookupWithClient(client, `x${HASH.slice(1)}`)).resolves.toEqual({
      outcome: OUTCOMES.UNKNOWN,
    });
    expect(client.request).not.toHaveBeenCalled();
  });

  it("keeps a transaction that is not yet validated unresolved (ported from ledgerReconciler)", async () => {
    const client = makeClient(async () => ({
      result: {
        hash: HASH,
        meta: { TransactionResult: "tesSUCCESS" },
        validated: false, // provisional application — meta can still flip
      },
    }));
    await expect(lookupWithClient(client, HASH)).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
  });
});

// ---- identity match BEFORE classification (audit art_FIvT05e6, violation 1)

const EXPECTED = {
  payer: "rEfcBKrxNp8mxL4xu46R5wL3ex4dpDE864",
  destination: "rEmployeeAccountXXXXXXXXXXXXXXXXXX",
  amount: "4.000000",
};

// A validated tesSUCCESS whose body matches the attempt's identity, exactly
// as a `tx` lookup returns it for a real Cadence payment.
const txBody = (overrides = {}) => ({
  hash: HASH,
  Account: EXPECTED.payer,
  Destination: EXPECTED.destination,
  Amount: { currency: RLUSD_CURRENCY, issuer: RLUSD_ISSUER, value: "4.000000" },
  SourceTag: SOURCE_TAG,
  meta: { TransactionResult: "tesSUCCESS" },
  validated: true,
  ...overrides,
});

describe("lookupWithClient identity match", () => {
  it("classifies tesSUCCESS as success when the transaction IS the attempt's payment", async () => {
    const client = makeClient(async () => ({ result: txBody() }));
    await expect(lookupWithClient(client, HASH, EXPECTED)).resolves.toEqual({
      outcome: OUTCOMES.SUCCESS,
    });
  });

  it("classifies a matched tec receipt as failure", async () => {
    const client = makeClient(async () => ({
      result: txBody({ meta: { TransactionResult: "tecUNFUNDED_PAYMENT" } }),
    }));
    await expect(lookupWithClient(client, HASH, EXPECTED)).resolves.toEqual({
      outcome: OUTCOMES.FAILURE,
    });
  });

  // Regression for audit probe P3: a wrong-recipient tesSUCCESS must park
  // unresolved with the anomaly surfaced, never advance a plan.
  it.each([
    ["wrong destination", { Destination: "rWrongRecipientXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" }],
    ["wrong amount value", { Amount: { currency: RLUSD_CURRENCY, issuer: RLUSD_ISSUER, value: "40.000000" } }],
    ["wrong amount type (XRP drops)", { Amount: "4000000" }],
    ["wrong payer", { Account: "rWrongPayerXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" }],
    ["wrong currency", { Amount: { currency: "58505200000000000000000000000000000000000000000000000000000000000000000000000000", issuer: RLUSD_ISSUER, value: "4.000000" } }],
    ["wrong issuer", { Amount: { currency: RLUSD_CURRENCY, issuer: "rWrongIssuerXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", value: "4.000000" } }],
    ["wrong source tag", { SourceTag: 12345 }],
    ["missing source tag", { SourceTag: undefined }],
  ])("stays unknown with anomaly identity_mismatch on %s", async (_label, overrides) => {
    const client = makeClient(async () => ({
      result: txBody({ meta: { TransactionResult: "tesSUCCESS" }, ...overrides }),
    }));
    await expect(lookupWithClient(client, HASH, EXPECTED)).resolves.toEqual({
      outcome: OUTCOMES.UNKNOWN,
      anomaly: "identity_mismatch",
    });
  });

  it("classifies without an identity check when no expected identity is supplied", async () => {
    // The bare-reconcile contract (pre-audit call sites) is unchanged.
    const client = makeClient(async () => ({ result: txBody() }));
    await expect(lookupWithClient(client, HASH)).resolves.toEqual({ outcome: OUTCOMES.SUCCESS });
  });
});

// ---- lookupTransaction: wiring against the real xrpl Client ---------------

const state = vi.hoisted(() => ({
  instances: [],
  lifecycle: [],
  connectError: null,
  requestError: null,
  requestResult: null,
  disconnectError: null,
}));

vi.mock("xrpl", () => {
  class MockClient {
    constructor(url) {
      this.url = url;
      state.instances.push(this);
    }
    async connect() {
      state.lifecycle.push("connect");
      if (state.connectError) throw state.connectError;
    }
    async request(request) {
      state.lifecycle.push("request");
      if (state.requestError) throw state.requestError;
      return state.requestResult;
    }
    async disconnect() {
      state.lifecycle.push("disconnect");
      if (state.disconnectError) throw state.disconnectError;
    }
  }
  return { Client: MockClient };
});

describe("lookupTransaction", () => {
  beforeEach(() => {
    state.instances.length = 0;
    state.lifecycle.length = 0;
    state.connectError = null;
    state.requestError = null;
    state.requestResult = null;
    state.disconnectError = null;
  });

  it("opens one client on mainnet, looks the hash up, and disconnects", async () => {
    state.requestResult = { result: { validated: true, hash: HASH, meta: { TransactionResult: "tesSUCCESS" } } };
    await expect(lookupTransaction(HASH)).resolves.toEqual({ outcome: OUTCOMES.SUCCESS });
    expect(state.instances).toHaveLength(1);
    expect(state.instances[0].url).toBe(XRPL_WS_URL);
    expect(state.lifecycle).toEqual(["connect", "request", "disconnect"]);
  });

  it("resolves still_unknown when the client cannot connect", async () => {
    state.connectError = new Error("getaddrinfo ENOTFOUND");
    await expect(lookupTransaction(HASH)).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
    // Never connected, so there is nothing to disconnect.
    expect(state.lifecycle).toEqual(["connect"]);
  });

  it("keeps a successful classification even if disconnect fails afterwards", async () => {
    state.requestResult = { result: { validated: true, hash: HASH, meta: { TransactionResult: "tesSUCCESS" } } };
    state.disconnectError = new Error("already closed");
    await expect(lookupTransaction(HASH)).resolves.toEqual({ outcome: OUTCOMES.SUCCESS });
  });

  it("returns exactly the normalized shape — nothing more", async () => {
    state.requestResult = { result: { validated: true, hash: HASH, meta: { TransactionResult: "tesSUCCESS" } } };
    const outcome = await lookupTransaction(HASH);
    expect(Object.keys(outcome)).toEqual(["outcome"]);
  });

  it("resolves still_unknown for a hash-less call without constructing a client", async () => {
    await expect(lookupTransaction("")).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
    await expect(lookupTransaction(null)).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
    expect(state.instances).toHaveLength(0);
  });

  it("builds no client for a malformed hash (ported from normalizeOutcome)", async () => {
    await expect(lookupTransaction(HASH.slice(1))).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
    await expect(lookupTransaction(`${HASH}F0`)).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
    expect(state.instances).toHaveLength(0);
  });

  it("keeps an unvalidated transaction unresolved even when the ledger answers (ported from ledgerReconciler)", async () => {
    state.requestResult = {
      result: {
        hash: HASH,
        meta: { TransactionResult: "tesSUCCESS" },
        validated: false,
      },
    };
    await expect(lookupTransaction(HASH)).resolves.toEqual({ outcome: OUTCOMES.UNKNOWN });
  });
});


describe("audit reconciliation regressions", () => {
  it("withholds a verdict unless validation is explicit", () => {
    expect(classifyTransactionResult({ meta: { TransactionResult: "tesSUCCESS" } })).toBe(OUTCOMES.UNKNOWN);
  });
  it("compares numerically equivalent RLUSD amounts and rejects partial payments", async () => {
    const expected = { payer: "rPayer", destination: "rRecipient", amount: "1.000000" };
    const tx = { validated: true, Account: expected.payer, Destination: expected.destination, DeliverMax: { currency: RLUSD_CURRENCY, issuer: RLUSD_ISSUER, value: "1" }, SourceTag: SOURCE_TAG, meta: { TransactionResult: "tesSUCCESS" } };
    const client = makeClient(async () => ({ result: tx }));
    expect((await lookupWithClient(client, HASH, expected)).outcome).toBe(OUTCOMES.SUCCESS);
    tx.Flags = 0x00020000;
    expect(await lookupWithClient(client, HASH, expected)).toMatchObject({ outcome: OUTCOMES.UNKNOWN, anomaly: "identity_mismatch" });
  });
});
